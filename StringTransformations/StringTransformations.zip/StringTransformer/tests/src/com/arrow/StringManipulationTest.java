package com.arrow;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringManipulationTest {

	private static final String STR = "Mary had a little lamb.";
	private static final String STRTwo = "MarY HaD A LiTtLe lAmB.";

	@Test
	public void removeCaps() {
		final StringTransformer st = new RemoveCaps();
		final String actual = st.transform(STR);

		assertEquals("ary had a little lamb.", actual);
	}
	
	@Test
	public void removeMultipleCaps() {
		final StringTransformer st = new RemoveCaps();
		final String actual = st.transform(STRTwo);

		assertEquals("ar a  ite lm.", actual);
	}

	@Test
	public void reverseSentence() {
		final StringTransformer st = new SentenceReverser();
		final String actual = st.transform(STR);

		assertEquals("lamb. little a had Mary", actual);
	}

	@Test
	public void reverseCharacters() {
		final StringTransformer st = new CharacterReverser();
		final String actual = st.transform(STR);

		assertEquals("yraM dah a elttil .bmal", actual);
	}

	@Test
	public void customReverse() {
		final StringTransformer st = new CustomReverser();
		final String actual = st.transform(STR);

		assertEquals(".BmAl eLtTiL A DaH YrAM", actual);
	}
	
	@Test
	public void chickenReplacer() {
		final StringTransformer st = new WordReplacer();
		final String actual = st.transform(STR);
		
		assertEquals("Mary had a little chicken.", actual);
	}
}
