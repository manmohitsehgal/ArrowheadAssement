package com.arrow;

public class CharacterReverser implements StringTransformer {

	@Override
	public String transform(String str) {
		// TODO Auto-generated method stub
		
		/*
		 * Algorithm : 
		 * - Pass the string into the StringBuilder.
		 * - Using the built in reverse property in the StringBuilder, reverse 
		 * 	 the string.
		 * - Use declared reverse function to reverse
		 * 	 every characters.
		 */
		
		StringBuilder stringToReverse = new StringBuilder(str);
		String reversedString = stringToReverse.reverse().toString();
	
		return reverse(reversedString);
	}
	
	public static String reverse(String str) {
		// TODO Auto-generated method stub
		String[] stringTokens = str.split(" ");
		int startPoint = (stringTokens.length) - 1;
		
		String reversedString = "";
		while(startPoint >= 0){
			reversedString += stringTokens[startPoint] + " ";
			startPoint--;
		}

		return reversedString.trim();
	}
	
	
	/*public static void main(String[] args){
		CharacterReverser r = new CharacterReverser();
		String rr = r.transform("Mary had a little lamb.");
		System.out.print(rr);
	}*/

}
