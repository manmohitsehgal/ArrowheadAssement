package com.arrow;

public interface StringTransformer {

	public String transform(String str);
	
}
