/*
 * Author : Manmohit Sehgal
 * Company: Arrowhead
 * Time spent: 1h 10 mins.
 */

package com.arrow;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class StringTransformerEngine {

	public static void main(String[] args) {

		final JFrame mainFrame = new JFrame("String Transformer");
		mainFrame.setSize(865, 500);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		final JPanel mainPanel = new JPanel(new BorderLayout());
		mainFrame.add(mainPanel);
		mainPanel.setLayout(null);

		JLabel inputLabel = new JLabel("Enter String: ");
		inputLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		inputLabel.setBounds(10, 10, 160, 25);
		mainPanel.add(inputLabel);

		JTextField inputStringField = new JTextField();
		inputStringField.setBounds(135, 10, 700, 25);
		mainPanel.add(inputStringField);

		JLabel outputValue = new JLabel("Enter value and click button to change output");
		outputValue.setBounds(10, 150, 800, 25);
		outputValue.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		outputValue.setHorizontalAlignment(JLabel.CENTER);
		outputValue.setVerticalAlignment(JLabel.CENTER);
		mainPanel.add(outputValue);

		/*
		 * =============REVERSE CHARACTER==============
		 * The button reverses the characters of the input string
		 * If the main input is empty, it outputs an error 
		 * message stating that the input is empty.
		 * It also updates the main input string once 
		 * the characters have been reversed.
		 * 
		 */
		JButton reverseChar = new JButton(new AbstractAction() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				CharacterReverser revChar = new CharacterReverser();
				if (inputStringField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Empty input",
							"Empty input", JOptionPane.PLAIN_MESSAGE);
				}
				else{
					outputValue.setText(revChar.transform(inputStringField.getText()));
					String updatedText = outputValue.getText();
					inputStringField.setText(updatedText);
				}
			}

		});

		reverseChar.setText("Reverse Characters");
		reverseChar.setBounds(15, 300, 200, 70);
		mainPanel.add(reverseChar);

		
		/*
		 * =============REVERSE SENTENCE==============
		 * The button reverses the input string
		 * If the main input is empty, it outputs an error 
		 * message stating that the input is empty.
		 * It also updates the main input string once 
		 * the sentence have been reversed.
		 */
		
		JButton reverseSentence = new JButton(new AbstractAction() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				CharacterReverser cRev = new CharacterReverser();

				if (inputStringField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Empty input",
							"Empty input", JOptionPane.PLAIN_MESSAGE);
				} else {
					outputValue.setText(cRev.transform(inputStringField.getText()));
					String updatedText = outputValue.getText();
					inputStringField.setText(updatedText);
				}

			}
		});

		reverseSentence.setText("Reverse Sentence");
		reverseSentence.setBounds(335, 380, 200, 70);
		mainPanel.add(reverseSentence);

		
		/*
		 * =============CUSTOME REVERSE==============
		 * The button reverses both the sentence and
		 * the characters of string.
		 * It also capitalizes the input string in two ways:
		 * 	- 1. If the first character is capitalized, it 
		 * 		 capitalizes every other character starting
		 * 		 from the second character
		 * -  2. If the first character is not capitalized,
		 * 		 it starts to capitalize every other character
		 * 		 starting from the first character.
		 * If the main input is empty, it outputs an error 
		 * message stating that the input is empty.
		 * It also updates the main input string once 
		 * the input have been reversed.
		 */

		
		JButton customeReverse = new JButton(new AbstractAction() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				CustomReverser cReverser = new CustomReverser();

				if (inputStringField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Empty input",
							"Empty input", JOptionPane.PLAIN_MESSAGE);
				} else {
					outputValue.setText(cReverser.transform(inputStringField.getText()));
					String updatedText = outputValue.getText();
					inputStringField.setText(updatedText);
				}
			}

		});

		customeReverse.setText("Custom Reverse");
		customeReverse.setBounds(225, 300, 200, 70);

		mainPanel.add(customeReverse);

		/*
		 * =============REPLACE WORDS==============
		 * The button replaces the words in the main
		 * string.
		 * It asks for user input for the word to change
		 * and changes that specific word.
		 * It outputs error message if the main string
		 * is empty or if the word in the string is
		 * not found.
		 * It also updates the main input string once 
		 * the word have been updated.
		 */
		
		JButton replaceWord = new JButton(new AbstractAction() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				JFrame replaceWordFrame = new JFrame("Word Replacer");
				replaceWordFrame.setSize(500, 500);
				JPanel replaceWordPanel = new JPanel();
				replaceWordPanel.setLayout(new GridLayout(6,2,1,1));
				
				JLabel wordToReplaceLabel = new JLabel("Word to replace:");
				wordToReplaceLabel.setBounds(5, 10, 60, 10);
				replaceWordPanel.add(wordToReplaceLabel);

				JTextField wordToReplaceField = new JTextField();
				wordToReplaceField.setBounds(10, 10, 300, 50);
				replaceWordPanel.add(wordToReplaceField);

				JLabel replaceWordLabel = new JLabel("Replace word with:   ");
				replaceWordPanel.add(replaceWordLabel);

				JTextField replaceWordField = new JTextField();
				replaceWordField.setBounds(10, 10, 300, 50);
				replaceWordPanel.add(replaceWordField);

				if (inputStringField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Empty input",
							"Empty input", JOptionPane.PLAIN_MESSAGE);
				} else {
					JButton changeWordOnClick = new JButton(new AbstractAction() {
								@Override
								public void actionPerformed(ActionEvent e) {
									// TODO Auto-generated method stub

									WordReplacer replaceWords = new WordReplacer();
									
									String findIn = inputStringField.getText();
									String replaceWord = wordToReplaceField.getText();
									
									if(findIn.indexOf(replaceWord) == -1){
										JOptionPane.showMessageDialog(null, "Word to change not found",
												"Invalid Input", JOptionPane.PLAIN_MESSAGE);
									}

									else{
										outputValue.setText(replaceWords.transformNew(inputStringField.getText(),wordToReplaceField.getText(),replaceWordField.getText()));
										replaceWordFrame.dispose();
										String updatedText = outputValue.getText();
										inputStringField.setText(updatedText);
									}

								}

							});

					changeWordOnClick.setText("Change word");
					changeWordOnClick.setAlignmentX(JButton.CENTER_ALIGNMENT);
					changeWordOnClick.setAlignmentY(JButton.CENTER_ALIGNMENT);

					replaceWordPanel.add(changeWordOnClick);

					replaceWordFrame.add(replaceWordPanel);
					replaceWordFrame.setVisible(true);
				}
			}

		});

		replaceWord.setText("Replace words");
		replaceWord.setBounds(435, 300, 200, 70);

		mainPanel.add(replaceWord);

		
		/*
		 * =============REMOVE CAPITALIZED CHARACTER==============
		 * The button removes the capitalized
		 * character in the main string.
		 * It outputs error message if the main string
		 * is empty and also updates the main input string 
		 * once the capitalized character has been removed.
		 */
		
		JButton removeCaps = new JButton(new AbstractAction() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				RemoveCaps removeCap = new RemoveCaps();

				if (inputStringField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Empty input",
							"Empty input", JOptionPane.PLAIN_MESSAGE);
				} else {
					outputValue.setText(removeCap.transform(inputStringField.getText()));
					String updatedText = outputValue.getText();
					inputStringField.setText(updatedText);
				}
			}
		});

		removeCaps.setText("Remove Caps");
		removeCaps.setBounds(645, 300, 200, 70);

		mainPanel.add(removeCaps);
		mainFrame.setVisible(true);
	}
}
