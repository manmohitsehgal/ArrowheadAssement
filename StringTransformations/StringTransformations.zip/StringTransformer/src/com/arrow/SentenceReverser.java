package com.arrow;

public class SentenceReverser implements StringTransformer {

	@Override
	public String transform(String str) {
		// TODO Auto-generated method stub
		
		/*
		 * Algorithm : 
		 * - Split the string into tokens.
		 * - Go through each token and reverse it.
		 * - Trim any unwanted white space at the end.
		 */
		
		String[] stringTokens = str.split(" ");
		int startPoint = (stringTokens.length) - 1;
		
		String reversedString = "";
		while(startPoint >= 0){
			reversedString += stringTokens[startPoint] + " ";
			startPoint--;
		}

		return reversedString.trim();
	}
	
	/*public static void main(String[] args){
		SentenceReverser sr = new SentenceReverser();
		String x = sr.transform("Mary had a little lamb.");
		System.out.println(x);
	}*/

}
