package com.arrow;

public class CustomReverser implements StringTransformer {

	@Override
	public String transform(String str) {
		// TODO Auto-generated method stub
		
		/*
		 * Algorithm : 
		 * - Split the string into tokens.
		 * - Check if the first character of the string is upper case
		 * 		-- If the first character is upper case, starting from the
		 * 		   second character, convert every other character into
		 * 		   upper case.
		 * - If the first character is not in upper case
		 * 		-- Starting from the first character, change every
		 * 		   second character to upper case.
		 * - Using the sentence reverse function (reverseWords), reverse
		 *   every word.
		 * - Using the character reverse function (reverseEveryChar), reverse
		 * 	 every character.
		 * - Trim any unwanted white spaces at the end.
		 */
		

		String[] myString = str.split("");
		String out = "";
		StringBuilder outString = new StringBuilder(str);
		StringBuilder finalString = new StringBuilder();
		if (Character.isUpperCase(outString.charAt(0))) {
			for (int i = 0; i < myString.length; i++) {
				if (i % 2 == 0) {
					finalString.append(myString[i]);
				} else {
					finalString.append(myString[i].toUpperCase());
				}

			}
		} else {
			for (int i = 0; i < myString.length; i++) {
				if (i % 2 == 0) {
					finalString.append(myString[i]);
				} else {
					finalString.append(myString[i].toUpperCase());
				}
			}
		}
		
		String customReversedString = reverseEveryChar(finalString.toString());
		return reverseWords(customReversedString);

	}
	
	public static String reverseEveryChar(String str){
		StringBuilder stringToReverse = new StringBuilder(str);
		String reversedString = stringToReverse.reverse().toString();
		
		return reverseWords(reversedString);
	}
	
	public static String reverseWords(String str) {
		// TODO Auto-generated method stub
		String[] stringTokens = str.split(" ");
		int startPoint = (stringTokens.length) - 1;
		
		String reversedString = "";
		while(startPoint >= 0){
			reversedString += stringTokens[startPoint] + " ";
			startPoint--;
		}

		return reversedString.trim();
	}

	/*public static void main(String[] args) {
		CustomReverser cr = new CustomReverser();
		String x = cr.transform("Mary had a little lamb.");
		System.out.println(x);
		// .BmAl eLtTiL A DaH YrAM
	}*/

}
