package com.arrow;

import java.util.HashMap;
import java.util.Map;

public class WordReplacer implements StringTransformer {

	@Override
	public String transform(String str) {
		// TODO Auto-generated method stub
		
		/*
		 * Algorithm : 
		 * - Using the replace all function, replace
		 *   every occurrence of lamb to chicken.
		 */
		
		return str.replaceAll("lamb", "chicken");
	}
	
	public String transformNew(String str, String toReplace, String replaceWith){
		return str.replaceAll(toReplace, replaceWith);
		
	}
	
	/*public static void main(String[] args){
		WordReplacer sr = new WordReplacer();
		String x = sr.transform("hello, lamb,you are now new lamb");
		String y = sr.transformNew("Hey bitch, this is going to work", "bitch", "man");
		System.out.println(y);
	}*/

}
