package com.arrow;

public class RemoveCaps implements StringTransformer {

	@Override
	public String transform(String str) {
		// TODO Auto-generated method stub
		
		/*
		 * Algorithm : 
		 * - Pass the string into the StringBuilder.
		 * - Find the index for upper case characters.
		 * - Use built in deleteCharAt function to delete the characters at found index.
		 */
		
		StringBuilder outString = new StringBuilder(str);
		int i = 0;
		while(i < outString.length()){
			if(Character.isUpperCase(outString.charAt(i))){
				outString.deleteCharAt(i);
				i--;
			}
			i++;
		}
		return outString.toString();
	}
	
	public static void main(String[] args){
		RemoveCaps rCaps = new RemoveCaps();
		String myStr = rCaps.transform("MarY HaD A LiTtLe lAmB.");
		System.out.println(myStr);
	}

}
